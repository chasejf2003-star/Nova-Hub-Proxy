# NovaHub

NovaHub as a real website. Games and apps open inside the site (same address,
no new tab) through a built-in Ultraviolet proxy.

## Put it online (free, about 10 minutes)

You need a free GitHub account and a free Render account. I can't create these
for you, but the steps are short.

1. **Upload to GitHub.** Make a new repository, then upload everything in this
   folder (drag and drop works on github.com). Don't upload `node_modules`.
2. **Deploy on Render.** On render.com choose New > Blueprint (or New > Web
   Service), pick your repository, and accept the settings. `render.yaml`
   already has them: build `npm install`, start `npm start`.
3. **Open your link.** Render gives you a `https://something.onrender.com`
   address. That's your NovaHub website. Share that link.

Notes for the free Render plan: the site sleeps after a while with no visitors
and takes about a minute to wake up on the next visit.

Prefer Replit? Create a Node.js Repl, upload these files, run `npm install`,
press Run, then use Deploy for a permanent link. Any host that runs Node and
supports WebSockets works (Railway, Fly.io, a VPS, or the included Dockerfile).

## Run on your own computer
1. Install Node.js 20 or newer.
2. `npm install` then `npm start`
3. Open http://localhost:8080 in Chrome or Edge.

## Custom domain
In Render open your service > Settings > Custom Domains and follow the
instructions to point your domain at it. HTTPS is added automatically.

## Adding or fixing games
Open `public/index.html` and search for `const LINKS=`. Each game name maps to
the page it should open. Games with no entry open that game's search results on
itch.io (inside NovaHub). Put a direct game page there for the best result.
Games listed in `const EMBED=` open directly with no proxy.

## If something doesn't load
- Press F12 and check the console. A message starting "NovaHub proxy
  unavailable" means the proxy didn't start. Make sure you opened the https
  link (or localhost).
- Firefox only works on https. Use Chrome or Edge on localhost.
- Some sites (logins, big 3D games) don't work through any proxy.
