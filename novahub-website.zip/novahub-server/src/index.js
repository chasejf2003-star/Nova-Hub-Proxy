import { createServer } from "node:http";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import express from "express";
import wisp from "wisp-server-node";

import { uvPath } from "@titaniumnetwork-dev/ultraviolet";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const publicPath = join(root, "public");

const app = express();
// NovaHub's own files first (including our uv.config.js), vendor files after.
app.use(express.static(publicPath));
app.use("/uv/", express.static(uvPath));
app.use("/epoxy/", express.static(epoxyPath));
app.use("/baremux/", express.static(baremuxPath));

app.get("/healthz", (req, res) => res.type("text").send("ok"));

app.use((req, res) => {
  res.status(404).sendFile(join(publicPath, "index.html"));
});

const server = createServer();

server.on("request", (req, res) => app(req, res));

// The proxy's network connection runs over this WebSocket.
server.on("upgrade", (req, socket, head) => {
  if (req.url.endsWith("/wisp/")) wisp.routeRequest(req, socket, head);
  else socket.end();
});

const port = parseInt(process.env.PORT || "8080", 10);
server.listen({ port, host: "0.0.0.0" }, () => {
  console.log(`NovaHub running on http://localhost:${port}`);
});

const shutdown = () => {
  console.log("Shutting down...");
  server.close();
  process.exit(0);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
